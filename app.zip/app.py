import os
from flask import Flask, request, render_template, jsonify
import mysql.connector
import fitz  # PyMuPDF for PDF text extraction
import re
from datetime import datetime

app = Flask(__name__)

# Configuration for file uploads
UPLOAD_FOLDER = os.path.join('static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Allowed file types
ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    """Check if the file is a valid PDF."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# MySQL Database Connection
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="my_database",
        port=3306
    )

# Extract form data using regular expressions
def extract_form_data(text):
    """Extracts data from the given text using regular expressions."""
    patterns = {
        "Name": r"Name.*?:\s*(.*)",
        "Email": r"Email ID.*?:\s*([\w\.-]+@[\w\.-]+)",
        "Mobile": r"Mobile.*?:\s*(\d{10})",
        "Date of Birth": r"Date of Birth.*?:\s*(\d{2}\s*/\s*\d{2}\s*/\s*\d{4})",
        "Gender": r"Gender.*?:\s*(\w+)",
        "Age": r"Age.*?:\s*(\d+)",
        "Emergency Contact's Name": r"Name of Emergency Contact:.*?(\w+\s\w+)",
        "Emergency Contact's Number": r"Emergency Contact's Number.*?:\s*(\d{10})",
        "Passport Number": r"Passport:\s([A-Z]{1}[0-9]{7})"
    }
    extracted_data = {}
    for field, pattern in patterns.items():
        match = re.search(pattern, text)
        extracted_data[field] = match.group(1).strip() if match else "Not Found"

    # Format Date of Birth
    if "Date of Birth" in extracted_data and extracted_data["Date of Birth"] != "Not Found":
        try:
            dob = extracted_data["Date of Birth"].replace(" /", "/")
            extracted_data["Date of Birth"] = datetime.strptime(dob, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            extracted_data["Date of Birth"] = "Invalid Date Format"

    return extracted_data

# Insert data into MySQL database
def insert_data_into_db(data):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check for duplicates
    check_query = "SELECT COUNT(*) FROM registrants WHERE email = %s"
    cursor.execute(check_query, (data["Email"],))
    count = cursor.fetchone()[0]

    if count > 0:
        cursor.close()
        conn.close()
        raise ValueError(f"A record with the email '{data['Email']}' already exists in the database.")

    insert_query = """
    INSERT INTO registrants (name, email, mobile, dob, gender, age, emergency_contact_name, emergency_contact_number, passport_number)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(insert_query, (
        data["Name"], data["Email"], data["Mobile"], data["Date of Birth"], data["Gender"],
        data["Age"], data["Emergency Contact's Name"], data["Emergency Contact's Number"], data["Passport Number"]
    ))

    conn.commit()
    cursor.close()
    conn.close()

# Extract text from a PDF file
def extract_text_from_pdf(pdf_file):
    """Extract text from an uploaded PDF file."""
    try:
        pdf_document = fitz.open(stream=pdf_file.read(), filetype="pdf")
        text = ""
        for page_num in range(len(pdf_document)):
            page = pdf_document.load_page(page_num)
            text += page.get_text()
        return text
    except Exception as e:
        return f"Error extracting text from PDF: {e}"

# Fetch students from the database
def fetch_students_from_db():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM registrants")
    students = cursor.fetchall()

    cursor.close()
    conn.close()
    return students

# Main route for file upload and processing
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        uploaded_files = request.files.getlist('files')  # Fetch multiple files
        if not uploaded_files:
            return "Please upload at least one .pdf file.", 400

        response = {"success": [], "errors": []}

        for uploaded_file in uploaded_files:
            if not uploaded_file.filename.endswith('.pdf'):
                response["errors"].append(f"Invalid file type: {uploaded_file.filename}")
                continue

            try:
                # Extract text and parse form data
                extracted_text = extract_text_from_pdf(uploaded_file)
                if extracted_text.startswith("Error"):
                    response["errors"].append(f"Error processing {uploaded_file.filename}: {extracted_text}")
                    continue

                form_data = extract_form_data(extracted_text)
                insert_data_into_db(form_data)
                response["success"].append(f"Processed: {uploaded_file.filename}")
            except Exception as e:
                response["errors"].append(f"Error processing {uploaded_file.filename}: {e}")

        return jsonify(response)  # Return a JSON response with success and error details

    # Render the form and fetch students for display
    return render_template('index.html', students=fetch_students_from_db())

if __name__ == '__main__':
    app.run(debug=True)
